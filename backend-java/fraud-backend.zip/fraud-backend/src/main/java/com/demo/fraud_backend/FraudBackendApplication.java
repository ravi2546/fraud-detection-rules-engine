package com.demo.fraud_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FraudBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(FraudBackendApplication.class, args);
	}

}
